package presentacion.vista;

import presentacion.vista.FrmAgregarPersona;
import javax.swing.*;
import java.awt.event.*;

public class FrmMenuPrincipal extends JFrame {

    private JMenuBar menuBar;
    private JMenu menuPersona;
    private JMenuItem itemAgregar;

    public FrmMenuPrincipal() {
        setTitle("Programa");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        menuBar = new JMenuBar();
        menuPersona = new JMenu("Persona");
        itemAgregar = new JMenuItem("Agregar");

        menuPersona.add(itemAgregar);
        menuBar.add(menuPersona);
        setJMenuBar(menuBar);

        itemAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FrmAgregarPersona agregar = new FrmAgregarPersona();
                agregar.setVisible(true);
            }
        });
    }
}