package main;

import presentacion.vista.FrmMenuPrincipal;

public class Principal {
    public static void main(String[] args) {
        FrmMenuPrincipal menu = new FrmMenuPrincipal();
        menu.setVisible(true);
    }
}