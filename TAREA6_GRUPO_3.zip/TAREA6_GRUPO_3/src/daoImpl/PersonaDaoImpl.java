package daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dao.PersonaDao;
import entidad.Persona;

public class PersonaDaoImpl implements PersonaDao {

    @Override
    public boolean insertar(Persona persona) {
        Connection cn = Conexion.getConexion().getSQLConexion();
        String query = "INSERT INTO Personas (Dni, Nombre, Apellido) VALUES ('" 
                        + persona.getDni() + "', '" 
                        + persona.getNombre() + "', '" 
                        + persona.getApellido() + "')";
        try {
            Statement st = cn.createStatement();
            return st.executeUpdate(query) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean existeDni(String dni) {
        Connection cn = Conexion.getConexion().getSQLConexion();
        String query = "SELECT Dni FROM Personas WHERE Dni = '" + dni + "'";
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
