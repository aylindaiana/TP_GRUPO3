package appEscritorio;

public class Principal {

	public static void main(String[] args) {
		Menu app = new Menu();
	}

}
